-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 30, 2025 at 04:26 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `study_planner`
--

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

CREATE TABLE `tasks` (
  `id` int(11) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `task` text NOT NULL,
  `due_date` date NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tasks`
--

INSERT INTO `tasks` (`id`, `subject`, `task`, `due_date`, `created_at`) VALUES
(1, 'Introduction to Programming', 'Learn basic programming concepts', '2002-01-22', '2025-08-30 02:06:20'),
(8, 'Introduction to Programming', 'Learn basic programming concepts', '2024-09-15', '2025-08-30 02:14:00'),
(9, 'Data Structures and Algorithms', 'Study fundamental data structures', '2024-09-22', '2025-08-30 02:14:00'),
(10, 'Database Design', 'Learn how to design relational databases', '2024-09-29', '2025-08-30 02:14:00'),
(11, 'Web Development Fundamentals', 'Build basic websites using HTML, CSS, and JavaScript', '2024-10-06', '2025-08-30 02:14:00'),
(12, 'Networking Basics', 'Understand computer networking principles', '2024-10-13', '2025-08-30 02:14:00'),
(13, 'Operating Systems', 'Study the principles of operating systems', '2024-10-20', '2025-08-30 02:14:00'),
(14, 'Software Engineering', 'Learn software development methodologies', '2024-10-27', '2025-08-30 02:14:00'),
(15, 'Cybersecurity Fundamentals', 'Introduction to cybersecurity concepts', '2024-11-03', '2025-08-30 02:14:00'),
(16, 'Mobile App Development', 'Build mobile apps for Android or iOS', '2024-11-10', '2025-08-30 02:14:00'),
(17, 'Cloud Computing', 'Explore cloud computing services and technologies', '2024-11-17', '2025-08-30 02:14:00'),
(18, 'Artificial Intelligence', 'Introduction to AI and machine learning', '2024-11-24', '2025-08-30 02:14:00'),
(19, 'Data Analysis', 'Learn how to analyze data using Python and Pandas', '2024-12-01', '2025-08-30 02:14:00'),
(20, 'Computer Architecture', 'Study the architecture of computer systems', '2024-12-08', '2025-08-30 02:14:00'),
(21, 'Human-Computer Interaction', 'Learn about designing user-friendly interfaces', '2024-12-15', '2025-08-30 02:14:00'),
(22, 'Information Security Management', 'Learn IS management best practices', '2024-12-22', '2025-08-30 02:14:00'),
(23, 'Ethical Hacking', 'Study hacking techniques for security testing', '2024-12-29', '2025-08-30 02:14:00'),
(24, 'Project Management for I.T.', 'Learn how to manage I.T. projects', '2025-01-05', '2025-08-30 02:14:00'),
(25, 'DevOps', 'Study the principles and practices of DevOps', '2025-01-12', '2025-08-30 02:14:00'),
(26, 'Big Data Technologies', 'Explore Big Data technologies like Hadoop and Spark', '2025-01-19', '2025-08-30 02:14:00'),
(27, 'Blockchain Technology', 'Introduction to blockchain and cryptocurrency', '2025-01-26', '2025-08-30 02:14:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tasks`
--
ALTER TABLE `tasks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
