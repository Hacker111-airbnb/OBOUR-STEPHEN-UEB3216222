<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "study_planner";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted
if (isset($_POST['submit'])) {
    // Get form data and sanitize
    $subject = mysqli_real_escape_string($conn, $_POST['subject']);
    $task = mysqli_real_escape_string($conn, $_POST['task']);
    $due_date = mysqli_real_escape_string($conn, $_POST['due_date']);
    
    // Insert data into database
    $sql = "INSERT INTO tasks (subject, task, due_date) VALUES ('$subject', '$task', '$due_date')";
    
    if ($conn->query($sql) === TRUE) {
        // Redirect back to form with success message
        header("Location: index.php?status=success");
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Close connection
$conn->close();
?>